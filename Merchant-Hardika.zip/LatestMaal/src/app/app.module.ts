﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {MerchantComponent} from './merchant';
import {FormsModule} from '@angular/forms';
import { Routes,RouterModule} from '@angular/router';
import {HttpClientModule} from '@angular/common/http';
import { ProfileComponent } from './profile-merchant';
import { InventoryControlComponent } from './inventory.component';
import { ShowProductClass } from './showproduct/showAll';
import { AddProductClass } from './addproduct/addProduct';
import{FileUploadModule} from 'ng2-file-upload'

const routes:Routes=[
   // {path: '', redirectTo: 'log', pathMatch: 'full' },
   //{ path: 'merchant', redirectTo: '/merchant',pathMatch: 'full' },
   {path:'',component:MerchantComponent},
    {path:'profile',component:ProfileComponent},
    {path:'merchant',component:MerchantComponent},
    {path:'inventoryControl',component:InventoryControlComponent},
   { path: 'addProduct', component:AddProductClass },
 { path: 'showProduct', component:ShowProductClass }
];

@NgModule({
    imports: [
        BrowserModule,FormsModule,RouterModule.forRoot(routes),HttpClientModule,FileUploadModule
        
    ],
    declarations: [
        AppComponent,ProfileComponent,MerchantComponent,InventoryControlComponent,ShowProductClass, AddProductClass
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }